=== CTL Brick Out ===
Tags: arkanoid, breakout, classic game, arcade game, retro game, touch game, wordpress game, admob, share score, leaderboard, bricks, blocks, powerups, pinball, retro game
Requires at least: 4.3
Tested up to: 4.3

Add Brick Out to CTL Arcade plugin

== Description ==
Add Brick Out to CTL Arcade plugin


	