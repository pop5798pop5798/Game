=== CTL Tap The Rat C2 ===
Tags: tap game, tapping game, cat, mouse, admob, catching game, catch, arcade game, wordpress game, survival game, skill game, endless game, logic game, funny game, arcade game
Requires at least: 4.3
Tested up to: 4.3

Add Tap The Rat C2 to CTL Arcade plugin

== Description ==
Add Tap The Rat C2 to CTL Arcade plugin


	